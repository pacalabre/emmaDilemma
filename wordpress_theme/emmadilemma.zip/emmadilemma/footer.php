<?php
/**
 * This is the footer template file
 * 
 *
 * @package emmadilemma
 * @since emmadilemma 1.0
 */
?>
  <footer class="footer">
    <h6> The Emma Dilemma <?php echo date("Y"); ?> &copy;</h6>
  </footer>
  <?php wp_footer(); ?>
</body>
</html>