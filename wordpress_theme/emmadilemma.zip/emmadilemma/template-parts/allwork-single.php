<?php
/**
 * The single template partial file for the view all work section 
 *
 * @package CustomTheme
 * @since CustomTheme 1.0
 */
?>

<section class="section-all-work">
  <a class="allwork-btn btn" href="../work">View All Work</a>
</section>