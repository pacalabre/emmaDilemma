<section class="row">
    <div class="col s12 category-nav">
        <a class="category-nav-item" href="/work"><h3 class="category-nav-item-h3">All</h3></a>
        <a class="category-nav-item" href="/index.php?p=189"><h3 class="category-nav-item-h3">Web</h3></a>
        <a class="category-nav-item" href="/index.php?p=191"><h3 class="category-nav-item-h3">Advertising</h3></a>
        <a class="category-nav-item" href="/index.php?p=193"><h3 class="category-nav-item-h3">Funsies</h3></a>
    </div>
</section>