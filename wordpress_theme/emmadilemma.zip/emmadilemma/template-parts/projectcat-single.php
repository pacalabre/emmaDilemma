<section class="row">
    <div class="col s12 category-nav">
        <a class="category-nav-item" href="/work"><h3 class="category-nav-item-h3">All</h3></a>
        <a class="category-nav-item" href="/work/web"><h3 class="category-nav-item-h3">Web</h3></a>
        <a class="category-nav-item" href="/work/advertising"><h3 class="category-nav-item-h3">Advertising</h3></a>
        <a class="category-nav-item" href="/work/funsies"><h3 class="category-nav-item-h3">Funsies</h3></a>
    </div>
</section>
